package com.vocahome.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(250, 246, 255)
    private val ink = Color.rgb(65, 57, 91)
    private val folders = linkedMapOf(
        "Music" to listOf("music", "audio", "spotify", "youtube music"),
        "Games" to listOf("game"),
        "Social" to listOf("chat", "social", "instagram", "discord"),
        "Tools" to listOf("settings", "camera", "clock", "file", "calculator")
    )
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun shape(color: Int, radius: Float = 24f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun base(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 20)
            setBackgroundColor(bg)
        }
        return root
    }

    private fun text(value: String, size: Float, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun showHome() {
        base()
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 22, 18, 22)
            background = shape(Color.rgb(235, 225, 255), 30f)
        }
        val time = SimpleDateFormat("h:mm", Locale.getDefault()).format(Date())
        val date = SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date())
        header.addView(text(time, 42f, ink, true))
        header.addView(text(date + "  ✦  Welcome home!", 15f))
        root.addView(header, LinearLayout.LayoutParams(-1, -2))
        val spacer = View(this); root.addView(spacer, LinearLayout.LayoutParams(1, 20))

        val subtitle = text("YOUR VOCALOID SPACE  ✧", 13f, Color.rgb(133, 111, 174), true)
        subtitle.gravity = Gravity.CENTER
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(View(this), LinearLayout.LayoutParams(1, 14))

        val keys = folders.keys.toList()
        for (row in 0..1) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (col in 0..1) {
                val name = keys[row * 2 + col]
                val tile = TextView(this).apply {
                    text = when(name) { "Music" -> "♫"; "Games" -> "✧"; "Social" -> "♡"; else -> "☾" } +
                        "\n$name\nOpen folder"
                    textSize = 18f; gravity = Gravity.CENTER; setTextColor(ink)
                    background = shape(if ((row + col) % 2 == 0) Color.rgb(230, 239, 255) else Color.rgb(245, 228, 249), 26f)
                    setPadding(8, 22, 8, 22)
                    setOnClickListener { showFolder(name) }
                }
                val lp = LinearLayout.LayoutParams(0, 150, 1f)
                if (col == 0) lp.marginEnd = 9 else lp.marginStart = 9
                line.addView(tile, lp)
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            if (row == 0) lp.bottomMargin = 18
            root.addView(line, lp)
        }
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        val search = EditText(this).apply {
            hint = "⌕  Search apps"
            textSize = 16f; setTextColor(ink); setSingleLine(true)
            setPadding(18, 12, 18, 12); background = shape(Color.WHITE, 28f)
            setOnEditorActionListener { _, _, _ -> showDrawer(text.toString()); true }
        }
        root.addView(search, LinearLayout.LayoutParams(-1, 54))
        root.addView(text("Hoshine Yuna  •  39  ✦", 12f, Color.rgb(145, 128, 177)).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, 32))
        setContentView(root)
    }

    private fun launcherApps(): List<Pair<String, String>> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }.sortedBy { it.first.lowercase() }
    }

    private fun showFolder(name: String) {
        base()
        root.addView(text("‹  $name", 28f, ink, true).apply {
            setOnClickListener { showHome() }
        })
        val matches = launcherApps().filter { app ->
            val words = folders[name] ?: emptyList()
            words.any { app.first.lowercase().contains(it) }
        }.take(12)
        if (matches.isEmpty()) {
            root.addView(text("No matching apps found yet.", 16f))
        } else {
            val grid = GridLayout(this).apply { columnCount = 2 }
            matches.forEach { app ->
                val item = TextView(this).apply {
                    text = "✦  ${app.first}"; textSize = 15f; gravity = Gravity.CENTER
                    setTextColor(ink); background = shape(Color.WHITE, 20f)
                    setPadding(12, 20, 12, 20)
                    setOnClickListener { launch(app.second) }
                }
                val lp = GridLayout.LayoutParams().apply {
                    width = 0; height = -2; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(5, 6, 5, 6)
                }
                grid.addView(item, lp)
            }
            root.addView(grid)
        }
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(text("‹ Back to home", 16f).apply { gravity = Gravity.CENTER; setOnClickListener { showHome() } })
        setContentView(root)
    }

    private fun showDrawer(query: String = "") {
        base()
        root.addView(text("All apps", 28f, ink, true))
        val input = EditText(this).apply { hint = "Search apps"; setText(query); setSingleLine(true) }
        root.addView(input)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this); scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fun refresh(q: String) {
            list.removeAllViews()
            launcherApps().filter { it.first.contains(q, true) }.forEach { app ->
                val item = text("✧   ${app.first}", 17f).apply {
                    setPadding(8, 14, 8, 14); setOnClickListener { launch(app.second) }
                }
                list.addView(item)
            }
        }
        refresh(query)
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh(s.toString()) }
            override fun afterTextChanged(s: Editable?) {}
        })
        root.addView(text("‹ Back to home", 16f).apply { gravity = Gravity.CENTER; setOnClickListener { showHome() } })
        setContentView(root)
    }

    private fun launch(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() { showHome() }
}
