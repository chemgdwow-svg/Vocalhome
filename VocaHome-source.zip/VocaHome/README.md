# VocaHome

A pastel Vocaloid-inspired Android home-screen replacement prototype.

## Build without a PC
1. Upload the contents of this repository to GitHub.
2. Open **Actions** → **Build VocaHome APK**.
3. Choose **Run workflow** (or push to `main` to trigger it).
4. When the workflow finishes, download the `VocaHome-debug-apk` artifact.

## Install
Download and extract the artifact, then install `app-debug.apk` on your Android device. Android may ask you to allow installation from your browser or file manager.

## Make it your home app
Press the Android Home button and choose **VocaHome**. You can change the default launcher later in Android Settings → Apps → Default apps → Home app.

## Notes
This is an early prototype. Folder contents are automatically matched by app-name keywords; folder editing, weather, custom icon packs, and persistent layout editing are not implemented. The workflow produces a debug APK, not a Play Store release-signed APK.
